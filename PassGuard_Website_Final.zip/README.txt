PASSGUARD WEBSITE

Files:
- index.html
- prototype.png

To publish:
1. Create a public GitHub repository named passguard-website.
2. Upload index.html and prototype.png.
3. GitHub -> Settings -> Pages.
4. Source: Deploy from a branch -> main -> /(root).
5. Save and wait for the Pages URL.

Replace the three team placeholders in index.html with your actual team names/roles before publishing.
